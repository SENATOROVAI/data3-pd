= Case Study 5
Covers Chapters 18-23

= Requirements
matplotlib
numpy
scipy
seaborn
pandas
sklearn
networkx
