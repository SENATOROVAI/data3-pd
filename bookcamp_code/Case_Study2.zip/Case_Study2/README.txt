= Case Study 2
Covers Chapters 5-9.

= Requirements
matplotlib
numpy
scipy
pandas
seaborn


