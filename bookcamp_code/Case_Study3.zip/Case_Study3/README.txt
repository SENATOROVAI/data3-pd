= Case Study 3
Covers Chapters 10-12.

= Requirements
matplotlib
numpy
scipy
pandas
sklearn
cartopy
geonamescache
unidecode
